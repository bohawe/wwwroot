
<div class = "msg_content">
<?php 
echo $msg;
?>
</div>