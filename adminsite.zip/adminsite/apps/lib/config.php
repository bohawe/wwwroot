<?php
	$GLOBALS['default_sbu'] = 'Aspire Zone';	
	$GLOBALS['default_report'] = 'Dashboard Maintenance';	
	$GLOBALS['title'] = 'Aspire Zone - Dashboard';	
	$GLOBALS['path'] = getcwd();
?>