
<?php
	/*
	$reportpage = "";		 
	$reportid = $_GET['reportid'];
	require  $_SERVER['DOCUMENT_ROOT'].'\apps\lib\dblayer\datalayer.php';
	
	$dblayer = new datalayer();
	$reportpage = $dblayer->getreporturl($reportid);
	
	if ($reportpage=='dberror') {exit;}
	
	if ($reportpage!=''){
?>
	
		<iframe  
		style="position:absolute;left:0;width:100%;height:100%;background-color:#fff;" frameBorder="0"
		src="<?php echo $reportpage; ?>" /></iframe>';
	

<?php
	}*/
	?>

