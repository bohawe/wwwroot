<?php	
	include 'apps/lib/config.php';
	require 'apps/lib/application.php';
	$app = new Application();	
?>


