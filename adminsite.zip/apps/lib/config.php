<?php
	$GLOBALS['default_sbu'] = 'Aspire Zone';	
	$GLOBALS['default_report'] = 'Welcome';	
	$GLOBALS['title'] = 'Aspire Zone - Dashboard';	
	
?>