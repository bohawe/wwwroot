
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300&display=swap" rel="stylesheet"> 
<link href="/public/css/welcome.css" rel="stylesheet" type="text/css" />	
<div class = "welcome_content">
	<div class = "welcome_header">		
		<div class = "welcome_title">Aspire Zone Dashboard</div>
	</div>	
	
	<div class = "welcome_header">
		
		<div class = "welcome_title_content"><span style=""><br/>The dashboard and report content from this website is exclusively shared to Aspire Zone clients and Partners only.<br/>Any information from this site is bounded by Aspire Zone Website Terms of Use </span></div>
	</div>	
	
		
</div>
